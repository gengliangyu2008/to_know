
public class FibonacciTest {

	public static int calc1(int num) {
		if( num == 1 || num == 2) {
			return 1;
		}
		
		return calc1(num-1) + calc1(num - 2);
	}
	
	public static int fibonacci2(int num) {
		if( num == 1 || num == 2 ) {
			return 1;
		}
		
		int fibonacciNum1 = 1;
		int fibonacciNum2 = 1;
		int fibonacciCurr = -1;
		for(int i=3; i<=num; i++) {
			fibonacciCurr = fibonacciNum1 + fibonacciNum2;
			
			fibonacciNum1 = fibonacciNum2;
			fibonacciNum2 = fibonacciCurr;
		}
		
		return fibonacciCurr;
	}
	
	 public static boolean isPrime(int number) {
	        int sqrt = (int) Math.sqrt(number) + 1;
	        for (int i = 2; i < sqrt; i++) {
	            if (number % i == 0) {
	                // number is perfectly divisible - no prime
	                return false;
	            }
	        }
	        return true;
	    }
	
	public static void main(String[] args) {
		
		for( int i=1; i<=10; i++ ) {
			System.out.print(fibonacci2(i) + " ");
		}
	}
}
