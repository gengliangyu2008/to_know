
public class AmstrongNumberTest {

	public static int getAmstrongNum(int num) {
		
		double power = (int)Math.log10(num) + 1;
		
		int result = 0;
		while( num > 0) {
			
			int reminder = num%10;
			result = result + (int) Math.pow(reminder, power);
			
			num = num/10;
		}
		
		return result;
	}
	
	public static boolean isAmstrongNum( int num ) {
		return getAmstrongNum(num) == num;
	}
	
	public static void main(String[] args) {
		int i = 999;
		
		System.out.println( getAmstrongNum(i) );
	}
}
