package design.pattern.command;

//Command

public interface Command {

	public void execute();

}