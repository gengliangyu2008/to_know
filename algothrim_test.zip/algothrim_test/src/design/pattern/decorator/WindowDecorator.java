package design.pattern.decorator;

//abstract decorator class - note that it implements Window
public abstract class WindowDecorator implements Window {
	protected Window window; // the Window being decorated

	public WindowDecorator(Window window) {
		this.window = window;
	}

	@Override
	public void draw() {
		window.draw(); // Delegation
	}

	@Override
	public String getDescription() {
		return window.getDescription(); // Delegation
	}
}