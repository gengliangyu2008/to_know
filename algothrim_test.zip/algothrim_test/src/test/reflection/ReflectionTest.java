package test.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;

import jdk.management.resource.internal.inst.SocketOutputStreamRMHooks;
import test.reflecEntity.Person;

public class ReflectionTest {

	public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		/*Class clz = Class.forName("test.reflection.PersonInSamePackage");
		Object p1 = new PersonInSamePackage(1, "aa", 11);*/
		Class clz = Class.forName("test.reflecEntity.Person");
		Object p1 = new Person(1, "aa", 11);
		
		
		System.out.println( "class loader:" + clz.getClassLoader().toString() );
		
		Method[] methods = clz.getDeclaredMethods();
		Arrays.stream(methods).forEach(t-> System.out.println(t.getName()));
		
		System.out.println("-----------------------------------------------");
		
		
		Method protectedM = clz.getDeclaredMethod("testProtected", new Class[] { Integer.TYPE });
		System.out.println( protectedM.isAccessible() );
		protectedM.setAccessible( true );
		System.out.println( protectedM.isAccessible() );
		
		Method friendlyM = clz.getDeclaredMethod("testFriendly", new Class[] { Integer.TYPE });
		System.out.println( friendlyM.isAccessible() );
		friendlyM.setAccessible( true );
		System.out.println( friendlyM.isAccessible() );
		
		Method privateM = clz.getDeclaredMethod("testPrivate", new Class[] { Integer.TYPE });
		System.out.println( privateM.isAccessible() );
		privateM.setAccessible( true );
		System.out.println( privateM.isAccessible() );
		
		protectedM.invoke( p1, 555);
		
		friendlyM.invoke( p1, 666);
		
		privateM.invoke( p1, 777);
		
	}
}