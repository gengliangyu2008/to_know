package test.reflecEntity;

public class Person {
	private int id;
	private String name;
	private int age;
	
	public Person(int id, String name, int age) {
		this.id = id;
		this.age = age;
		this.name = name;
	}
	
	private void testPrivate(int i) {
		System.out.println("in test private, i===" + i);
	}
	
	void testFriendly(int i) {
		System.out.println("in test friendly, i===" + i);
	}
	
	protected void testProtected(int i) {
		System.out.println("in test protected, i===" + i);
	}
	
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
}