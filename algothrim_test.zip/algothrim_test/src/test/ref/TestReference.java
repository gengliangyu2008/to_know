package test.ref;
import java.util.WeakHashMap;

public class TestReference {

	public static void main(String[] args) {
		WeakHashMap<String, String> map = new WeakHashMap<>();
		
		map.put("111", "a1");
		map.put("222", "a2");
		map.put("333", "a3");
		
		System.out.println( map.get("222") );
		
		
	}
}
