package test.ref;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;

public class ReferenceTest {

	public void testWeakReference() throws Exception {
		Object obj = new Object();
		WeakReference<Object> weakRef = new WeakReference<Object>(obj);
		obj = null;
		
		for( int i=0; i<3; i++) {
			Thread.sleep(1000);
			System.gc();
			System.out.println("gc executed:" + i);
		}
		
		System.out.println( weakRef.get() );
	}
	
	public void testSoftReference() throws Exception {
		Object obj = new Object();
		SoftReference<Object> softRef = new SoftReference<Object>(obj);
		obj = null;
		
		for( int i=0; i<3; i++) {
			Thread.sleep(1000);
			System.gc();
			System.out.println("gc executed:" + i);
		}
		
		System.out.println( softRef.get() );
	}

	
	public void testPhantomReferenceWithQ() throws Exception {
		ReferenceQueue<Object> q = new ReferenceQueue<Object>();
		
		Object obj = new Object();
		PhantomReference<Object> phantomRef = new PhantomReference<Object>(obj, q);
		q.remove();
		
		for( int i=0; i<3; i++) {
			Thread.sleep(1000);
			System.gc();
			System.out.println("gc executed:" + i);
		}
		
		System.out.println( phantomRef.get() );
	}
	
	public static void main(String[] args) throws Exception {
		
		new ReferenceTest().testWeakReference();
		//new ReferenceTest().testSoftReference();
		//new ReferenceTest().testPhantomReferenceWithQ();

	}
}
