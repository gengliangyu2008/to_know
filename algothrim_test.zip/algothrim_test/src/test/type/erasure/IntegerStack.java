package test.type.erasure;

import java.util.Stack;

public class IntegerStack extends Stack<Integer> {
	
	private static final long serialVersionUID = 5541637070396065940L;

	public IntegerStack(int capacity) {
        //super(capacity);
    }
 
    public Integer push(Integer value) {
        return super.push(value);
    }
    
    public void test1() {
    	IntegerStack integerStack = new IntegerStack(5);
    	Stack stack = integerStack;
    	stack.push("Hello");
    	//Integer data = (Integer) integerStack.pop();
    	//Integer data = integerStack.pop();
    	//Integer data1 = stack.pop();
    	
    	//System.out.println(stack.pop());
    }
    
    public void test2() {
    	IntegerStack integerStack = new IntegerStack(5);
    	Stack stack = (IntegerStack) integerStack;
    	stack.push("Hello");
    	//Integer data = (String) integerStack.pop();
    }
    
    public void test3() {
    	IntegerStack integerStack = new IntegerStack(5);
    	Stack stack = integerStack;
    	stack.push("Hello");
    	Integer data = integerStack.pop();
    	System.out.println( data );
    }
    
    public static void main(String[] args) {
	
    	IntegerStack intStack = new IntegerStack(10);
    	intStack.test1();
	}
}