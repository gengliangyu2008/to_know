package test.type.erasure;

public class TestGenerics<T> {

	public void testMethod(T t) {
		System.out.println(t.getClass().getName());
	}

	public T testMethod1(T t) {
		return t;
	}
}
