package test.type.erasure;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class TestIntegerStack extends Stack<Integer> {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -6625917361153663837L;

	public TestIntegerStack(int capacity) {
		
	}
	
	public Integer push(Integer value) {
        return super.push(value);
    }
	
	public void test3() {
    	
    	TestIntegerStack integerStack = new TestIntegerStack(10);
    	Stack stack = integerStack;
    	stack.push("Hello");
    	Integer data = integerStack.pop();
    	System.out.println( data );
    	System.out.println( 123 );
    }
	
	public void test4() {

		ArrayList<String> arrList = new ArrayList<>();
		arrList.add("abc");
		
		List list = arrList;
		list.add(123);
		
		System.out.println( list.get(0) );
		System.out.println( list.get(1) );
    }
    
    public static void main(String[] args) {
    	
		new TestIntegerStack(10).test4();
	}
}
