package exoduspoint;

import java.util.ArrayList;
import java.util.List;

public class Result2 {
    public static List<String> closestStraightCity(List<String> c, List<Integer> x, List<Integer> y, List<String> q){

        List<String> result = new ArrayList<>();

        int m=-1;
        int n=-1;

        for(int i=0;i<x.size();i++){
            Integer xI = x.get(i);
            for(int j=0;j<x.size();j++){
                Integer xJ = x.get(j);
                if(xI == xJ){
                    // result.add(c.get(i));
                    m=i;
                }
            }
        }
        for(int i=0;i<y.size();i++){
            Integer xI = y.get(i);
            for(int j=1;j<y.size();j++){
                Integer xJ = x.get(j);
                if(xI == xJ){
                    //result.add(c.get(i));
                    n=i;
                }
            }
        }

        if(m!=-1 || n!=-1){
            if(m!=-1){
                result.add(c.get(m));
            }
            if(n!=-1){
                result.add(c.get(n));
            }

        }else{
            result.add("none");
        }
        return result;
    }

    public static List<String> closestStraightCity1(List<String> c, List<Integer> x, List<Integer> y, List<String> q) {
        List<String> result = new ArrayList<>();

        for (int k = 0; k < c.size(); k++) {
            int currentX = x.get(k);
            int currentY = y.get(k);

            int closestDistance = Integer.MAX_VALUE;
            String closestCity = "NONE";

            for (int i = 0; i < x.size(); i++) {

                if (i != k && (x.get(i) == currentX || y.get(i) == currentY)) {
                    int distance = Math.abs(x.get(i) - currentX) + Math.abs(y.get(i) - currentY);
                    if (distance < closestDistance) {
                        closestDistance = distance;
                        closestCity = c.get(i);
                    } else if (distance == closestDistance) {
                        closestCity = closestCity.compareTo(c.get(i)) > 0 ? c.get(i) : closestCity;
                    }
                }
            }
            result.add(closestCity);
        }
        return result;
    }
}
