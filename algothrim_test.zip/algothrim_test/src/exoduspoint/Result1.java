package exoduspoint;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

class Result1 {

    /*
     * Complete the 'timeOfBuffering' function below.
     *
     * The function is expected to return an INTEGER.
     * The function accepts following parameters:
     *  1. INTEGER arrivalRate
     *  2. INTEGER_ARRAY packets
     */

    public static int timeOfBuffering(int arrivalRate, List<Integer> packets) {
        int numOfPackets = packets.size()/arrivalRate;
        Set<Integer> buffer = new LinkedHashSet<>();

        for(int i=1; i<=numOfPackets; i++) {
            boolean validPacketsOrBuffer = false;

            for(int j=0; j<arrivalRate; j++) {
                int current = packets.get( (i-1) * arrivalRate + j);
                if(current < i) {
                    continue;
                }
                if ( current == i ) {
                    if (j == 0) {
                        validPacketsOrBuffer = true;
                        buffer.remove(i);
                    } else {
                        if (buffer.contains(i)) {
                            validPacketsOrBuffer = true;
                            buffer.remove(i);
                        }
                    }
                } else {
                    if(!buffer.contains(current)) {
                        buffer.add(current);
                    }
                }
            }

            if(!validPacketsOrBuffer) {
                return i;
            }
        }
        return -1;
    }
}
