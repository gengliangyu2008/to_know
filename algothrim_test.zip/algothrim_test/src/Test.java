
public class Test {

	public static void main(String[] args) {
		int i = 0;
		
		i = ++i;
		
		System.out.println(i);
		//System.out.println(j);
	}
}
