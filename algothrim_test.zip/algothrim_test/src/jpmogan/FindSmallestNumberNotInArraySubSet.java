package jpmogan;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;

/*
 * all numbers in array are positive, unsorted and might be repetitive. 
 */
public class FindSmallestNumberNotInArraySubSet {

	public int solution(int[] arr) {
		Arrays.sort( arr );
		
		int candidate = 1;

		for (int value : arr) {
			if (value > candidate) {
				return candidate;
			}
			candidate = candidate + value;
		}
		return candidate;
	}
	
    int findSmallest(int[] arr)  {
    	
    	Arrays.sort( arr );
        
    	int res = 1;
        // Traverse the array and increment 'res' if arr[i] is
        // smaller than or equal to 'res'.
        for (int i = 0; i < arr.length && arr[i] <= res; i++)
            res = res + arr[i];
 
        return res;
    }
    
	
	@Test
	public void test1() {
		int arr[] = {1, 3, 6, 10, 11, 15};
		int res = solution(arr);
		
		assertEquals(res, 2);
	}
	
	@Test
	public void test2() {
		int arr[] = {1, 1, 1, 1};
		int res = solution(arr);
		
		assertEquals(res, 5);
	}
	
	@Test
	public void test3() {
		int arr[] = {1, 1, 3, 4};
		int res = solution(arr);
		
		assertEquals(res, 10);
	}
	
	@Test
	public void test4() {
		int arr[] = {1, 2, 5, 10, 20, 40};
		int res = solution(arr);
		
		assertEquals(res, 4);
	}
	
	@Test
	public void test5() {
		int arr[] = {1, 2, 3, 4, 5, 6};
		int res = solution(arr);
		
		assertEquals(res, 22);
	}
	
	@Test
	public void test6() {
		int arr[] = {1, 2, 3, 4, 5, 6};
		int res = findSmallest(arr);
		
		assertEquals(res, 22);
	}
}
