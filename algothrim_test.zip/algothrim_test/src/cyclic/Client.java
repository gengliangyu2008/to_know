package cyclic;

import java.util.concurrent.CyclicBarrier;

public class Client {
	public static void main(String[] args) {
		Runnable r1 = new Runnable() {
			public void run() {
				System.out.println("r1 executed ");
			}
		};
		Runnable r2 = new Runnable() {
			public void run() {
				System.out.println("r2 executed ");
			}
		};

		CyclicBarrier barrier1 = new CyclicBarrier(2, r1);
		
		CyclicBarrier barrier2 = new CyclicBarrier(2, r2);

		CyclicBarrierRunnable barrierRunnable1 = new CyclicBarrierRunnable(barrier1, barrier2);

		CyclicBarrierRunnable barrierRunnable2 = new CyclicBarrierRunnable(barrier1, barrier2);

		new Thread(barrierRunnable1).start();
		new Thread(barrierRunnable2).start();
	}
}
