package hirevue.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Main {
    /**
     * Iterate through each line of input.
     */
    public static void main(String[] args) throws IOException {
        InputStreamReader reader = new InputStreamReader(System.in, StandardCharsets.UTF_8);
        BufferedReader in = new BufferedReader(reader);
        String line;
        int i=0;
        String firstLine = "";
        String secondLine = "";
        while ((line = in.readLine()) != null) {
            System.out.println(line);
            if (i == 0) {
                firstLine = line;
            } else {
                secondLine = line;
            }
            i++;
        }

        String[] edgeArr = secondLine.split(";");

        Main obj = new Main();
        TreeSet<String> ascendingNodeSet = obj.getDistinctElementSet(edgeArr);

        Graph graph = obj.createGraph(ascendingNodeSet, edgeArr);

        for (String dest : ascendingNodeSet) {
            obj.BFS(graph, firstLine, dest, edgeArr.length);
        }

    }

    public TreeSet<String> getDistinctElementSet(String[] edgeArr) {
        TreeSet<String> nodeSet = new TreeSet<>();
        Arrays.stream(edgeArr).forEach(
                str -> {
                    String[] pair = str.split(",");
                    nodeSet.add(pair[0]);
                    nodeSet.add(pair[1]);
                }
        );
        return nodeSet;
    }
    public Graph createGraph(TreeSet<String> nodeSet, String[] edgeArr) {

        HashMap<String, Integer> nodePosMap = new HashMap<>();
        int i=0;
        for(String str : nodeSet) {
            nodePosMap.put(str, i++);
        }

        Graph graph = new Graph(nodePosMap.size());
        for (String str : edgeArr) {
            String[] pair = str.split(",");
            int x = nodePosMap.get(pair[0]);
            int y = nodePosMap.get(pair[1]);

            graph.addEdge(x, y);
        }

        return graph;
    }

    public int BFS(Graph graph, int src, int dest, int numOfVertices) {

        boolean[][] adj = graph.adjacencyMatrix;

        int[] distances = new int[numOfVertices];
        boolean[] visited = new boolean[numOfVertices];

        for (int i = 0; i < numOfVertices; i++) {
            visited[i] = false;
            distances[i] = Integer.MAX_VALUE;
        }

        visited[src] = true;
        distances[src] = 0;

        LinkedList<Integer> queue = new LinkedList<>();
        queue.add(src);

        while (!queue.isEmpty()) {
            int curr = queue.remove();
            boolean[] row = adj[curr];

            for (int i=0; i<row.length; i++) {
                if ( row[i] && !visited[i] ) {

                    queue.add(i);

                    visited[i] = true;
                    distances[i] = distances[curr] + 1;

                    if (i == dest)
                        return distances[dest];
                }
            }
        }
        return -1;
    }

}