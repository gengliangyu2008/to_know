package hirevue.test;

import java.util.TreeSet;

public class SolutionContext {
    private String[] pairArr;
    private TreeSet<String> ascendingNodeSet;

    public String[] getPairArr() {
        return pairArr;
    }

    public void setPairArr(String[] pairArr) {
        this.pairArr = pairArr;
    }

    public TreeSet<String> getAscendingNodeSet() {
        return ascendingNodeSet;
    }

    public void setAscendingNodeSet(TreeSet<String> ascendingNodeSet) {
        this.ascendingNodeSet = ascendingNodeSet;
    }
}
