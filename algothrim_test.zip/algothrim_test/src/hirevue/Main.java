package hirevue;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class Main {
    /**
     * Iterate through each line of input.
     */
    public static void main(String[] args) throws IOException {
        InputStreamReader reader = new InputStreamReader(System.in, StandardCharsets.UTF_8);
        BufferedReader in = new BufferedReader(reader);
        String line;
        int i=0;
        String firstLine = "";
        String secondLine = "";
        while ((line = in.readLine()) != null) {
            System.out.println(line);
            if (i == 0) {
                firstLine = line;
            } else {
                secondLine = line;
            }
            i++;
        }

        Main obj = new Main();
        obj.solution(firstLine, secondLine);
    }

    public void solution(String startPoint, String edgeList) {
        String[] edgeArr = edgeList.split(";");

        TreeSet<String> nodeSet = new TreeSet<>();
        for (String str : edgeArr) {
            String[] pair = str.split(",");
            nodeSet.add(pair[0]);
            nodeSet.add(pair[1]);
        }

        Map<String, Integer> nodePosMap = new HashMap<>();
        int i=0;
        for(String str : nodeSet) {
            nodePosMap.put(str, i++);
        }

        Graph graph = new Graph(nodePosMap.size());
        for (String str : edgeArr) {
            String[] pair = str.split(",");
            int x = nodePosMap.get(pair[0]);
            int y = nodePosMap.get(pair[1]);

            graph.addEdge(x, y);
        }

        //======================================
        for (String str : edgeArr) {
            String[] pair = str.split(",");
            int x = nodePosMap.get(pair[0]);
            int y = nodePosMap.get(pair[1]);

            graph.addEdge(x, y);
        }
    }


}

class Graph {
    private boolean adjacencyMatrix[][];
    private int vertexCount;

    public Graph(int vertexCount) {
        this.vertexCount = vertexCount;
        adjacencyMatrix = new boolean[vertexCount][vertexCount];
    }

    public void addEdge(int i, int j) {
        if (i >= 0 && i < vertexCount && j > 0 && j < vertexCount) {
            adjacencyMatrix[i][j] = true;
            adjacencyMatrix[j][i] = true;
        }
    }

    public boolean isEdge(int i, int j) {
        if (i >= 0 && i < vertexCount && j > 0 && j < vertexCount)
            return adjacencyMatrix[i][j];
        else
            return false;
    }
}