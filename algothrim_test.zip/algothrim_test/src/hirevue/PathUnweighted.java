package hirevue;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class PathUnweighted {

    public static void main(String[] args) {
        int numOfVertices = 8;

        ArrayList<ArrayList<Integer>> adj = new ArrayList<>(numOfVertices);
        for (int i = 0; i < numOfVertices; i++) {
            adj.add(new ArrayList<>());
        }

        addEdge(adj, 0, 1);
        addEdge(adj, 0, 3);
        addEdge(adj, 1, 2);
        addEdge(adj, 3, 4);
        addEdge(adj, 3, 7);
        addEdge(adj, 4, 5);
        addEdge(adj, 4, 6);
        addEdge(adj, 4, 7);
        addEdge(adj, 5, 6);
        addEdge(adj, 6, 7);
        int source = 3, dest = 7;

        /*
            0 1 2 3 4 5 6 7
         0  Y Y N Y N N N N
         1  Y Y Y N N N N N
         2  N Y Y N N N N N
         3  Y N N Y Y N N Y
         4  N N N Y Y Y Y Y
         5  N N N N Y Y Y N
         6  N N N N Y Y Y Y
         7  N N N Y Y N Y Y
        }
        */
        printShortestDistance(adj, source, dest, numOfVertices);
    }

    // function to form edge between two vertices source and dest
    private static void addEdge(ArrayList<ArrayList<Integer>> adj, int i, int j) {
        adj.get(i).add(j);
        adj.get(j).add(i);
    }

    private static void printShortestDistance(ArrayList<ArrayList<Integer>> adj, int s, int dest, int numOfVertices) {

        int result = BFS(adj, s, dest, numOfVertices);

        if ( result == -1 ) {
            System.out.println("Given source and destination are not connected");
            return;
        }
        System.out.println("Shortest path length is: " + result);
    }

    private static int BFS(ArrayList<ArrayList<Integer>> adj, int src, int dest, int numOfVertices) {

        int[] distances = new int[numOfVertices];
        boolean[] visited = new boolean[numOfVertices];

        for (int i = 0; i < numOfVertices; i++) {
            visited[i] = false;
            distances[i] = Integer.MAX_VALUE;
        }

        visited[src] = true;
        distances[src] = 0;

        LinkedList<Integer> queue = new LinkedList<>();
        queue.add(src);

        /*
            0 1 2 3 4 5 6 7
         0  Y Y N Y N N N N
         1  Y Y Y N N N N N
         2  N Y Y N N N N N
         3  Y N N Y Y N N Y
         4  N N N Y Y Y Y Y
         5  N N N N Y Y Y N
         6  N N N N Y Y Y Y
         7  N N N Y Y N Y Y
        }
        */

        // bfs Algorithm
        while (!queue.isEmpty()) {
            int curr = queue.remove();
            List<Integer> edgeList = adj.get(curr);

            for (Integer temp : edgeList) {

                if ( !visited[temp] ) {

                    queue.add(temp);

                    visited[temp] = true;
                    distances[temp] = distances[curr] + 1;

                    if (temp == dest)
                        return distances[dest];
                }
            }
        }
        return -1;
    }
}