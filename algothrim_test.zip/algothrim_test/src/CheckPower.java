import jdk.management.resource.internal.inst.SocketOutputStreamRMHooks;

public class CheckPower {

	
	public static void main(String[] args) {

		//String binaryIntInStr = Integer.toBinaryString(25);
		
		System.out.println( Integer.toBinaryString(-1) );
		
		System.out.println( Integer.parseInt("-5", 2) );
		
		System.out.println( Integer.toBinaryString(5) );

		System.out.println( Integer.toBinaryString(25) );
		
		System.out.println( Integer.toBinaryString(125) );
		
		System.out.println( Integer.toBinaryString(125*5) );
		
		System.out.println( Integer.toBinaryString(125*5*5) );
		
		System.out.println( Integer.toBinaryString(125*5*5*5) );
	}
}
