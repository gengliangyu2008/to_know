
public class MathTest {

	public static void main(String[] args) {
		double d1 = Math.log(Math.E);
		
		System.out.println(d1);
		
		System.out.println( Math.E );
		
		
		System.out.println( Math.log10( 100 ) );
	}
}
