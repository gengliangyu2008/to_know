package amazon;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class SortListOfList {

	List<List<Integer>> closestLocations(int totalCrates, List<List<Integer>> allLocations, int truckCapacity) {
		
		Collections.sort(allLocations, new Comparator<List<Integer>>() {
			@Override
			public int compare(List<Integer> o1, List<Integer> o2) {
				return Math.abs(o1.get(0)) + Math.abs(o1.get(1)) - Math.abs(o2.get(0)) - Math.abs(o2.get(1));
			}
		});
		
		return allLocations.subList(0, truckCapacity);
	}
	
	/*int getSquareSum(int x, int y) {
		return x*x + y*y; 
	}*/
	
	public static void main(String[] args) {
		List list1 = new LinkedList<>();
		list1.add(3);
		list1.add(6);
		
		List list2 = new LinkedList<>();
		list2.add(2);
		list2.add(4);
		
		List list3 = new LinkedList<>();
		list3.add(5);
		list3.add(3);
		
		List list4 = new LinkedList<>();
		list4.add(2);
		list4.add(7);
		
		List list5 = new LinkedList<>();
		list5.add(1);
		list5.add(9);
		
		List list6 = new LinkedList<>();
		list6.add(7);
		list6.add(9);
		
		List totalList = new LinkedList();
		
		totalList.add(list5);
		totalList.add(list6);
		totalList.add(list1);
		totalList.add(list2);
		totalList.add(list3);
		totalList.add(list4);
		
		List rrList = new SortListOfList().closestLocations(6, totalList, 3);
		System.out.println(rrList.size());
	}
}
