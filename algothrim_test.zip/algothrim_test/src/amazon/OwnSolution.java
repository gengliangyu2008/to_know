package amazon;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class OwnSolution {

	List<List<Integer>> closestLocations(int totalCrates, List<List<Integer>> allLocations, int truckCapacity) {
		
		List<List<Integer>> result = new LinkedList<>();
			
		for(int i=0; i<allLocations.size(); i++) {
			
			List<Integer> currentLocation = allLocations.get(i);
			int currentSum = getSquareSum(currentLocation.get(0), currentLocation.get(1));
			
			if( result.size() > 0 ) {
				
				for( int j=0; j<result.size(); j++) {
					
					if( currentSum <= getSquareSum(result.get(j).get(0), result.get(j).get(1) ) ) {
						
						result.add(j, currentLocation);
						break;

					} else {
					
						if ( j == result.size() - 1) {
							result.add(currentLocation);
							break;
						}
					}
				}
				
			} else {
				result.add(currentLocation);
			}
		}
		
		return result.subList(0, truckCapacity);
	}
	
	
	int getSquareSum(int x, int y) {
		return x*x + y*y; 
	}
	
	public static void main(String[] args) {
		List list1 = new LinkedList<>();
		list1.add(3);
		list1.add(6);
		
		List list2 = new LinkedList<>();
		list2.add(2);
		list2.add(4);
		
		List list3 = new LinkedList<>();
		list3.add(5);
		list3.add(3);
		
		List list4 = new LinkedList<>();
		list4.add(2);
		list4.add(7);
		
		List list5 = new LinkedList<>();
		list5.add(1);
		list5.add(9);
		
		List list6 = new LinkedList<>();
		list6.add(7);
		list6.add(9);
		
		List totalList = new LinkedList();
		
		totalList.add(list1);
		totalList.add(list2);
		totalList.add(list3);
		totalList.add(list4);
		totalList.add(list5);
		totalList.add(list6);
		
		List rrList = new OwnSolution().closestLocations(6, totalList, 3);
		System.out.println(rrList.size());
	}
}
