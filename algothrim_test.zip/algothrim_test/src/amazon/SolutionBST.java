package amazon;


public class SolutionBST {
	
	public int getDistanace(BSTNode root, BSTNode node1, BSTNode node2) {

		if (root == null || node1 == null || node2 == null)
			return 0;
		BSTNode ancestor = findLCA(root, node1, node2);
		int ancestorDepth = getNodeDepth(root, ancestor); 
		int node1Depth = getNodeDepth(root, node1); 
		int node2Depth = getNodeDepth(root, node2); 
		return node1Depth + node2Depth - 2 * ancestorDepth;

	}

	private BSTNode LCA(BSTNode root, BSTNode node1, BSTNode node2) {
		if (root == null)
			return null;
		if (root == node1 || root == node2)
			return root;
		BSTNode left = LCA(root.getLeft(), node1, node2); 
		BSTNode right = LCA(root.getRight(), node1, node2); 
		if(left != null && right != null)
			return root;
		return left == null? right: left;
	}
	
	

	private int getDepth(BSTNode curr, BSTNode target) {
		if (curr == null)
			return -1;
		if (curr == target)
			return 0;
		int left = getDepth(curr.getLeft(), target);
		int right = getDepth(curr.getRight(), target);
		if (left == -1 && right == -1)
			return -1;
		return left == -1? right + 1: left + 1;
	}
	
	private int getNodeDepth(BSTNode root, BSTNode target) {
		if( root == null ) {
			return -1;
		}
		if( root == target ) {
			return 0;
		}
		int left = getNodeDepth(root.getLeft(), target);
		int right = getNodeDepth(root.getRight(), target);
		
		if( left == -1 && right == -1) {
			return -1;
		}
		if( left != -1 ) {
			return left + 1;
		}
		if( right != -1 ) {
			return right + 1;
		}
		return -1;
	}
	
	public BSTNode findLCA(BSTNode root, BSTNode node1, BSTNode node2) {
		if( root == null ) {
			return null;
		}
		if( root.getValue() == node1.getValue() || root.getValue() == node2.getValue() ) {
			return root;
		}
		
		BSTNode left = findLCA(root.getLeft(), node1, node2);
		BSTNode right = findLCA(root.getRight(), node1, node2);
		
		if( left != null && right != null ) {
			return root;
		}
		if( left != null ) {
			return left;
		}
		if( right != null ) {
			return right;
		}
		return null;
	}
	
	public int bstDistance(int[] values, int n, int node1, int node2) {
		
		BSTNode root = createTree(values);
		
		BSTNode bstNode1 = searchIteratively(root, node1);
		BSTNode bstNode2 = searchIteratively(root, node2);
		
		if( bstNode1 == null || bstNode2 == null) {
			return 0;
		}
		
		return getDistanace(root, bstNode1, bstNode2);
	}
	
	BSTNode createTree(int[] values) {
		
		BSTNode root = new BSTNode( null, values[0] );
		
		for( int i=1; i<values.length; i++ ) {
			root.addNode(values[i]);
		}
		return root;
	}
	
	BSTNode searchTree(BSTNode root, int node) {
		
		if( root.getValue() == node ) {
			return root;
		}
		if( root.getLeft() != null ) {
			searchTree(root.getLeft(), node);
		}
		if( root.getRight() != null ) {
			searchTree(root.getRight(), node);
		}
		return null;
	}
	
	public BSTNode searchIteratively(BSTNode root, int value) {
		BSTNode temp = root;
		while(temp != null ) {
			if( temp.getValue() == value ) {
				return temp;
			} else if ( value < temp.getValue() ) {
				temp = temp.getLeft();
			} else {
				temp = temp.getRight();
			}
		}
		return null;
	}
	public static void main(String[] args) {
		
		SolutionBST bst = new SolutionBST();
		
		/**
		 * The tree is from below link:
		 *  
		 * http://lcm.csa.iisc.ernet.in/dsa/node91.html
		 * 
		 */
		
		int[] arr = {13, 3, 4, 12, 14, 10, 5, 1, 8, 2, 7, 9, 11, 6, 18};
		
		System.out.println("distance================" + bst.bstDistance(arr, arr.length, 10, 6) );
	}
	
	void preOrderTraverse(BSTNode root) {
		
		System.out.println( root.getValue());
		
		if( root.getLeft() != null ) {
			preOrderTraverse(root.getLeft());
		}
		
		if( root.getRight() != null ) {
			preOrderTraverse(root.getRight());
		}
	}
}

class BSTNode {
	private BSTNode left;
	private BSTNode right;
	private BSTNode parent;
	
	private int value;

	BSTNode(BSTNode parent, int value) {
		this.value = value;
		this.parent = parent;
		this.left = null;
		this.right = null;
	}

	public void addNode(int num) {
		if (num < this.value) {
			if (this.left != null) {
				this.left.addNode(num);
			} else {
				this.left = new BSTNode(this, num);
			}
		} else {
			if (this.right != null) {
				this.right.addNode(num);
			} else {
				this.right = new BSTNode(this, num);
			}
		}
	}
	
	public String toString() {
		return String.valueOf(value);
	}

	public BSTNode getLeft() {
		return left;
	}

	public BSTNode getRight() {
		return right;
	}

	public void setLeft(BSTNode left) {
		this.left = left;
	}

	public void setRight(BSTNode right) {
		this.right = right;
	}

	public BSTNode getParent() {
		return parent;
	}

	public void setParent(BSTNode parent) {
		this.parent = parent;
	}

	public int getValue() {
		return value;
	}
}