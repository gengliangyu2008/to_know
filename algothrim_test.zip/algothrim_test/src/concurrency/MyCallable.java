package concurrency;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledThreadPoolExecutor;

public class MyCallable implements Callable<String> {

	Object obj = new Object();
	
	@Override
	public String call() throws Exception {
		//System.out.println("in the method of call........");
		
		synchronized (obj) {
			System.out.println("before sleep");
			Thread.sleep(2000);
			System.out.println("after sleep");
		}
		
		// return the thread name executing this callable task
		return Thread.currentThread().getName();
	}

	public static void main(String args[]) throws Exception {
		// Get ExecutorService from Executors utility class, thread pool size is 10
		ExecutorService executor = Executors.newFixedThreadPool(10);
		
		// create a list to hold the Future object associated with Callable
		List<Future<String>> list = new ArrayList<Future<String>>();
		
		// Create MyCallable instance
		Callable<String> callable = new MyCallable();
		
		Runnable runnable = new MyRunnable();
		
		for (int i = 0; i < 10; i++) {
			
			// submit Callable tasks to be executed by thread pool
			Future<String> future = executor.submit(callable);
			
			System.out.println( future.getClass().getName() );
			
			// add Future to the list, we can get return value using Future
			list.add(future);
			
			//executor.execute( runanble );
			
			//Thread t = new Thread( runanble );
			//t.start();
		}
		
		System.out.println("All future tasks have been added into list");
		System.out.println( new Date() );
		
		for (Future<String> fut : list) {
			try {
				// print the return value of Future, notice the output delay in console
				// because Future.get() waits for task to get completed
				System.out.println(fut.get() + "::" + new Date() );
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}
		}
		// shut down the executor service now
		//executor.shutdown();
	}
}

class MyRunnable implements Runnable{
	
	public void run() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println( Thread.currentThread().getName() );
	}
}