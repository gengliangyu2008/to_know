package concurrency;

import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class ThreadFacotryTest {

	public static void main(String[] args) {
		ThreadFactory factory = Executors.defaultThreadFactory();
	
		factory.newThread( new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
		});
	}
}
