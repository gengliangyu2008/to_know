package concurrency;

import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public class FutureTaskTest {

	public static void main(String[] args) {
		Callable<String> obj = () -> { return  ""; };
		FutureTask<String> ft = new FutureTask<String>( () -> { return  ""; } );
	}
}
