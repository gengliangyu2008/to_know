
public class PalindromeTest {

	public static int reverseNum(int num) {
		
		int reversedNum = 0;
		while( num != 0 ) {
			
			int reminder = num%10;
			
			reversedNum = reversedNum * 10 + reminder;
			
			num = num/10;
			
			/*if( num >= 1) {
				
				reversedNum = (reversedNum + reminder)*10;
				
			} else {
				
				reversedNum = reversedNum + reminder;
			}*/
			
		}
		
		return reversedNum;
	}
	
	public static int reverse(int number) {
		int reverse = 0;
		
		while( number!=0 ) {
			reverse = reverse*10 + number%10;
			System.out.println("number======" + number + ",reverse======" + reverse);
			number = number/10;
		}
		return reverse;
	}
	public static void main(String[] args) {
		
		//System.out.println( reverseNum(121));
		
		System.out.println( reverseNum(99663));
		//System.out.println( reverse(123));
	}
}


/*
 * 123 -> reminder:3, num = 12;
 * 12 -> reminder:2, num = 1;
 * 1 -> reminder:1, num = 0;
 * 
 * */
