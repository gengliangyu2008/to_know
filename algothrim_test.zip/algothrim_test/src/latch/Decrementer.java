package latch;

import java.util.concurrent.CountDownLatch;

public class Decrementer implements Runnable {

    CountDownLatch latch = null;

    public Decrementer(CountDownLatch latch) {
        this.latch = latch;
    }

    public void run() {

        try {
            Thread.sleep(1000);
            System.out.println("count down 1");
            this.latch.countDown();

            Thread.sleep(1000);
            System.out.println("count down 2");
            this.latch.countDown();

            Thread.sleep(1000);
            System.out.println("count down 3");
            this.latch.countDown();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
