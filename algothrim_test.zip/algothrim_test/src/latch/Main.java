package latch;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Main {

	public static void main(String[] args) throws InterruptedException {
		CountDownLatch latch = new CountDownLatch(3);

		Waiter      waiter      = new Waiter(latch);
		Decrementer decrementer = new Decrementer(latch);

		//new Thread(waiter)     .start();
		//new Thread(decrementer).start();
		
		ExecutorService executorService = Executors.newCachedThreadPool();

		executorService.execute( waiter );
		executorService.execute( decrementer );
		
		//executorService.shutdown();
		
		executorService.awaitTermination(1000, TimeUnit.SECONDS);
		
		System.out.println("main thread completed!!!!!!!!!!!");
	}
}
