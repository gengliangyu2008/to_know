package leetcode;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class LongestSubstringWithoutRepeating {
	
    /*public int lengthOfLongestSubstring(String s) {
    	
    	int lastMaxLength = 0;
    	int lastRepeatedIndex = -1;
    	
    	LinkedHashSet<Character> currLinkedSet = new LinkedHashSet<>();
        for( int i=0; i<s.length(); i++ ) {
        	if ( currLinkedSet.contains( s.charAt(i) ) ) {
        		
        		if ( currLinkedSet.size() -1 - lastRepeatedIndex > lastMaxLength ) {
        			lastMaxLength = currLinkedSet.size() -1 - lastRepeatedIndex;
        		}
        		
        		lastRepeatedIndex = i;
        		Iterator<Character> iter = currLinkedSet.iterator();
        		
        		while( iter.hasNext() ) {
        			Character c = iter.next();
        			iter.remove();
        			if( c.equals( s.charAt(i) ) ) {
        				break;
        			}
        		}
        	}
        	currLinkedSet.add( s.charAt(i) );
        }
        
        return Math.max(lastMaxLength, (s.length() -1) - lastRepeatedIndex);
    }*/
    
	//123983454123151
    
   /* public int calcLongestSubstring(String s) {
    	
    	Set<Character> hashset = new HashSet<>();
    	
    	int i = 0;
    	int j = 0;
    	int maxLength = 0;
    	
    	while( i < s.length() && j < s.length() ) {
    		
    		if( !hashset.contains( s.charAt(j) ) ) {
    			hashset.add( s.charAt(j) );
    			j++;
    			
    			maxLength = Math.max( j-i, maxLength );
    		} else {
    			hashset.remove( s.charAt(i) );
    			i++;
    		}
    	}
    	
    	return maxLength;
    	
    }*/
    
    public int lengthOfLongestSubstring(String s) {
        int n = s.length(), ans = 0;
        int[] index = new int[128]; // current index of character
        // try to extend the range [i, j]
        for (int j = 0, i = 0; j < n; j++) {
            i = Math.max(index[s.charAt(j)], i);
            ans = Math.max(ans, j - i + 1);
            index[s.charAt(j)] = j + 1;
        }
        return ans;
    }
    
	public int lengthOfLongestSubstringAA(String s) {
		int[] idx = new int[128];
		for (int i = 0; i < idx.length; i++)
			idx[i] = -1;

		int ans = 0, start = 0;
		for (int i = 0; i < s.length(); i++) {
			int cIdx = s.charAt(i);
			if (idx[cIdx] >= start)
				start = idx[cIdx] + 1;
			idx[cIdx] = i;
			ans = Math.max(ans, i - start + 1);
		}
		return ans;
	}

	public int solutionWithMap(String s) {
		if (s.length() == 0)
			return 0;

		HashMap<Character, Integer> map = new HashMap<>();
		int result = 0;
		for (int i = 0, j = 0; i < s.length(); ++i) {
			if (map.containsKey(s.charAt(i))) {
				int dupPos = map.get(s.charAt(i));
				j = Math.max(j, dupPos + 1);
			}
			map.put(s.charAt(i), i);
			result = Math.max(result, i - j + 1);
		}
		return result;
	}
    
    
    public static void main(String[] args) {
    	/*String s = "zcdvabdef";
    	
    	LongestSubstringWithoutRepeating lswr = new LongestSubstringWithoutRepeating();
    	
    	System.out.println( lswr.lengthOfLongestSubstring( s ) );*/
    	
    	/*char c = 0;
    	System.out.println( String.valueOf( c ) );
    	System.out.println( " " );*/
    	
    	String a = "abcdef";
    	
    	System.out.println( a.length() );
    	System.out.println( (int)a.charAt(1) );
    	
	}
}
