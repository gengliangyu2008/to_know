package leetcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CombinationSum2 {
    public List<List<Integer>> combinationSum2(int[] candidates, int target) {
    	
    	List<List<Integer>> resultList = new ArrayList<>();
    	
    	List<Integer> tempList = new ArrayList<>();
    	
    	Arrays.sort( candidates );
    	
    	backTrack(resultList, tempList, candidates, 0, 8);
    	
    	return resultList;
    }
    
    private void backTrack(List<List<Integer>> resultList, List<Integer> tempList, int[] candidates, int startPos, int remaining) {
    	if( remaining < 0 ) {
    		return;
    	} else if ( remaining == 0 ) {
    		resultList.add( new ArrayList<>( tempList ) );
    	} else {
    		
    		for( int i=startPos; i<candidates.length; i++ ) {
    			//if(i > startPos && candidates[i] == candidates[i-1]) continue;
    			
    			tempList.add( candidates[i] );
    			
    			backTrack(resultList, tempList, candidates, i+1, remaining - candidates[i] );
    			//System.out.println( "current list:" + listToString(tempList) + " \t| remove value:" + tempList.get( tempList.size() - 1 ) ); 
    			tempList.remove( tempList.size() - 1 );
    		}
    	}
    }
    
	private static String listToString(List<Integer> list) {
		StringBuilder strBuilder = new StringBuilder();
		for( int i=0; i< list.size(); i++ ) {
			strBuilder.append( String.valueOf(list.get(i) ) );
			strBuilder.append( "," );
		}
		return strBuilder.toString();
	}
    
    public static void main(String[] args) {
    	int[] arr = { 1, 1, 2, 5, 6, 7, 10 };
    	
    	List<List<Integer>> l = new CombinationSum2().combinationSum2(arr, 8);
    	
    	for( List<Integer> list : l ) {
    		System.out.println( listToString(list) );
    	}
	}
}
