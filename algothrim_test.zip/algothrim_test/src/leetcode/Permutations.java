package leetcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Permutations {

	public List<List<Integer>> permute(int[] num) {
		List<List<Integer>> result = new ArrayList<>();
		
		
		
		return result;
	}
	
	private void loopRecursively(List<List<Integer>> list, int[] nums) {
		
		for( int i = 0; i<nums.length; i++ ) {
			
		}
	}
	
    static void permute(List<Integer> arr, int k){
        for(int i = k; i < arr.size(); i++){
            Collections.swap(arr, i, k);
            permute(arr, k+1);
            Collections.swap(arr, k, i);
        }
        if (k == arr.size() -1){
            System.out.println( Arrays.toString(arr.toArray()) );
        }
    }
    
    public List<List<Integer>> permuteWithShortCode(int[] num) {
        LinkedList<List<Integer>> res = new LinkedList<List<Integer>>();
        
        res.add(new ArrayList<Integer>());
        for (int n : num) {
            int size = res.size();
            for (; size > 0; size--) {
                List<Integer> r = res.pollFirst();
                for (int i = 0; i <= r.size(); i++) {
                    List<Integer> t = new ArrayList<Integer>(r);
                    t.add(i, n);
                    res.add(t);
                }
            }
        }
        return res;
    }
    
	public static List<List<Integer>> permuteNew(int[] num) {
		List<List<Integer>> ans = new ArrayList<List<Integer>>();
		
		List<Integer> l0 = new ArrayList<Integer>();
		l0.add(num[0]);
		
		ans.add(l0);
		
		for (int i = 1; i < num.length; ++i) {
			List<List<Integer>> new_ans = new ArrayList<List<Integer>>();
			
			for (int j = 0; j <= i; ++j) {
			
				for (List<Integer> curr : ans) {
				
					List<Integer> new_l = new ArrayList<Integer>( curr );
					new_l.add(j, num[i]);
					new_ans.add(new_l);
				}
			}
			ans = new_ans;
		}
		return ans;
	}
    
    public static void main(String[] args) {
		/*List<Integer> list = Arrays.asList(1, 2, 3, 4);
		permute(list, 0);*/
		
		int[] nums = {1, 2, 3, 4};
		permuteNew(nums);
		
		
	}
}
