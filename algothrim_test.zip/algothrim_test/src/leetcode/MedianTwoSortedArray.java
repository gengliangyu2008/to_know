package leetcode;

import java.util.Arrays;

public class MedianTwoSortedArray {

    public double findMedianSortedArrays(int[] nums1, int[] nums2) {
        int[] arr = new int[nums1.length + nums2.length];
        
        for( int i=0; i<nums1.length; i++ ) {
        	arr[i] = nums1[i];
        }
        
        for( int j=0; j<nums2.length; j++ ) {
        	arr[nums1.length + j] = nums2[j];
        }
        
        Arrays.sort( arr );
        
        if( arr.length%2 == 0 ) {
        	int index = arr.length/2;
        	return ( (double)(arr[index] + arr[index-1]) )/2;
        }
        
        return arr[arr.length/2];
    }
    
	public static void main(String[] args) {
		
	}
}
