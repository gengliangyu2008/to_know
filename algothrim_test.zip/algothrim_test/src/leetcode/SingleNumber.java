package leetcode;

public class SingleNumber {
	
	public int singleNumber(int[] nums) {
		int x = 0;
        for( int i=0; i<nums.length; i++ ) {
        	x ^= nums[i]; 
        }
        return x;
    }
	
	public static void main(String[] args) {
		int i = 0;
		int j = 19;
		
		System.out.println( i ^ j );
	}
}
