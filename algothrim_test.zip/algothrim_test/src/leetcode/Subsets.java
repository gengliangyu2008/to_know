package leetcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Subsets {

    public List<List<Integer>> subsets(int[] nums) {
    	List<List<Integer>> results = new ArrayList<>();
    	
    	List<Integer> tempList = new ArrayList<>();
    	
    	backTrack(results, tempList, nums, 0);
    	
    	return results;
    }
    
    private void backTrack(List<List<Integer>> results, List<Integer> tempList, int[] nums, int startPos) {
    	
    	List<Integer> newTempList = new ArrayList<>( tempList );
    	System.out.println( listToString(newTempList) );
    	results.add( newTempList );
    	
    	for(int i=startPos; i<nums.length; i++ ) {
    		tempList.add( nums[i] );
    		backTrack(results, tempList, nums, i+1);
    		tempList.remove( tempList.size() - 1 );
    	}
    }
    
    /*private void backtrack(List<List<Integer>> list , List<Integer> tempList, int [] nums, int start){
        list.add(new ArrayList<>(tempList));
        for(int i = start; i < nums.length; i++){
            tempList.add(nums[i]);
            backtrack(list, tempList, nums, i + 1);
            tempList.remove(tempList.size() - 1);
        }
    }*/
    
	private static String listToString(List<Integer> list) {
		StringBuilder strBuilder = new StringBuilder("[");
		for( int i=0; i< list.size(); i++ ) {
			strBuilder.append( String.valueOf(list.get(i) ) );
			strBuilder.append( "," );
		}
		strBuilder.append( "]" );
		return strBuilder.toString();
	}
	
	public void printAllSubsets(List<Integer> list) {
		List<Integer> temp = new ArrayList<>();
		
		printRecursively(list, temp, 0);
    }
	
	private void printRecursively(List<Integer> list, List<Integer> temp, int startPos) {
		System.out.println( listToString(temp) );
		for(int i=startPos; i<list.size(); i++ ) {
			temp.add( list.get(i) );
			printRecursively(list, temp, i+1);
			temp.remove( temp.size() - 1 );
		}
	}
	
	
	static void printSubsets(int[] arr) {

		int n = arr.length;

		// Run a loop for printing all 2^n subsets one by one
		for (int i = 0; i < (1 << n); i++) {
			System.out.print("{");

			// Print current subset
			for (int j = 0; j < n; j++)

				// (1<<j) is a number with jth bit 1
				// so when we 'and' them with the
				// subset number we get which numbers
				// are present in the subset and which
				// are not
				if ((i & (1 << j)) > 0)
					System.out.print(arr[j] + ",");

			System.out.println("}");
		}
	}
	
	
	static void useMask(int[] arr) {
		int N = arr.length;
		int allMasks = (1 << N);
		
		System.out.println( "allMasks=======" + allMasks );
		
		for (int i = 1; i < allMasks; i++) {
			for (int j = 0; j < N; j++)
				if ((i & (1 << j)) > 0) // The j-th element is used
					System.out.print((j + 1) + " ");

			System.out.println();
		}
	}
	
	public static void main(String[] args) {
		int[] nums = {15, 20, 22, 29};
		//int[] nums = {1, 2, 3};
		//new Subsets().subsets(nums);
		//Integer[] nums = { 1, 3, 2 };
		//new Subsets().printAllSubsets( Arrays.stream(nums).boxed().collect( Collectors.toList() ) );
		
		//printSubsets( nums );
		
		//System.out.println( 1 << 1 );
		
		useMask(nums);
	}
}
