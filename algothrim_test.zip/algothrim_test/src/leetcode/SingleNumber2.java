package leetcode;

import com.sun.org.apache.xerces.internal.util.SynchronizedSymbolTable;

public class SingleNumber2 {

	/*public int singleNumber(int[] nums) {
		if( nums.length == 1 ) {
			return nums[0];
		}
		
		int x = nums[0];
        for( int i=1; i<nums.length-2; i +=3 ) {
        	x = x | nums[i] & nums[i+1] ^ nums[i+2]; 
        }
        return x;
    }*/
	
    public int singleNumber(int[] nums) {
    	quick_sort_recursive(0, nums.length-1, nums);
    	
    	int i=0;
    	int result = 0;
    	while( i < nums.length ) {
    		
    		if( i == nums.length -1 ) {
    			result = nums[i];
    			break;
    		}
    		if( nums[i] != nums[i+1] ) {
    			result = nums[i];
    			break;
    		}
    		i +=3;
    	}
    	return result;
    }
	
	public void quick_sort_recursive(int startIndex, int endIndex, int[] arr) {
		if (startIndex >= endIndex) {
			return;
		}
		
		int mid = arr[endIndex];
		int left = startIndex;
		int right = endIndex - 1;
		
		while (left < right) {
			while (arr[left] < mid && left < right)
				left++;
			while (arr[right] >= mid && left < right)
				right--;
			
			int temp = arr[left];
			arr[left] = arr[right];
			arr[right] = temp;
		}
		if (arr[left] >= arr[endIndex]) {
			int temp = arr[left];
			arr[left] = arr[endIndex];
			arr[endIndex] = temp;
		} else {
			
			left++;
		}
		
		quick_sort_recursive(startIndex, left - 1, arr);
		quick_sort_recursive(left + 1, endIndex, arr);
	}

	public static void main(String[] args) {
		/*int[] arr = {2,2,3,2};
		
		System.out.println( new SingleNumber2().singleNumber(arr) );*/
		
		/*int k = 2 | 2 & 3 ^ 2;
		
		System.out.println( k );
		
		System.out.println( 2 | 2 );
		System.out.println( 2 | 2 & 3 );
		
		System.out.println( 2 ^ 2 );
		
		 System.out.println( 2 & 3 );*/
		
		/*int j = 2 & 2 ^ 2 | 3;
		
		System.out.println( j );*/
		
		/*
		System.out.println( 2 ^ 0 );
		
		System.out.println( 2 & 2 ^ 2 );
		
		System.out.println( 2 & 2 ^ 2 );*/
		
		int i = 0;
		int j = ~i;
		System.out.println( "maxValue:\t" + Integer.toBinaryString( Integer.MAX_VALUE ) );
		System.out.println( "minValue:\t" + Integer.toBinaryString( Integer.MIN_VALUE ) );
		System.out.println( j + ":\t\t" + Integer.toBinaryString(j) );
		System.out.println( "-2:\t\t" + Integer.toBinaryString(-2) );
		System.out.println( "-3:\t\t" + Integer.toBinaryString(-3) );
	}
}
