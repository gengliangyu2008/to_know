package leetcode;

public class MedianOfTwoSortedArr2 {
	
    public double findMedianSortedArrays(int[] A, int[] B) {
        int m = A.length;
        int n = B.length;
        if (m > n) { // to ensure m<=n
            int[] temp = A; A = B; B = temp;
            int tmp = m; m = n; n = tmp;
        }
        int startIndex = 0, mIndex = m, halfLen = (m + n + 1) / 2;
        
        while (startIndex <= mIndex) {
        
        	int i = (startIndex + mIndex) / 2;
            int j = halfLen - i;
            
            if (i < mIndex && B[j-1] > A[i]){
            	startIndex++; // i is too small
            }
            
            else if (i > startIndex && A[i-1] > B[j]) {
            	mIndex--; // i is too big
            
            } else { // i is perfect
            	
                int maxLeft = 0;
                if (i == 0) { maxLeft = B[j-1]; }
                else if (j == 0) { maxLeft = A[i-1]; }
                else { maxLeft = Math.max(A[i-1], B[j-1]); }
                if ( (m + n) % 2 == 1 ) { return maxLeft; }

                int minRight = 0;
                if (i == m) { minRight = B[j]; }
                else if (j == n) { minRight = A[i]; }
                else { minRight = Math.min(B[j], A[i]); }

                return (maxLeft + minRight) / 2.0;
            }
        }
        return 0.0;
    }
    
	public double findMedianSortedArrays11(int[] nums1, int[] nums2) {
		int m = nums1.length;
		int n = nums2.length;

		if (m > n) {
			int[] temp = nums1;
			nums1 = nums2;
			nums2 = temp;
			int t = m;
			m = n;
			n = t;
		}

		int halfLength = (m + n + 1) / 2;
		int fromIndex = 0;
		int toIndex = m;
		while (true) {
			int i = (fromIndex + toIndex) / 2;
			int j = halfLength - i;

			if (i != 0 && nums1[i - 1] > nums2[j]) {
				toIndex = i - 1;
			} else if (i != m && nums1[i] < nums2[j - 1]) {
				fromIndex = i + 1;
			} else {
				int leftMax;
				if (i == 0) {
					leftMax = nums2[j - 1];
				} else if (j == 0) {
					leftMax = nums1[i - 1];
				} else {
					leftMax = Math.max(nums1[i - 1], nums2[j - 1]);
				}
				if ((m + n) % 2 == 1) {
					return leftMax;
				}

				int rightMin;
				if (i == m) {
					rightMin = nums2[j];
				} else if (j == n) {
					rightMin = nums1[i];
				} else {
					rightMin = Math.min(nums1[i], nums2[j]);
				}
				return (leftMax + rightMin) / 2.0;
			}
		}
	}
	int[] nums1 = {1, 4, 4, 8, 9}; //length=5, halfLength = 6
	int[] nums2 = {2, 3, 5, 6, 6, 7, 10}; //length=7
}
