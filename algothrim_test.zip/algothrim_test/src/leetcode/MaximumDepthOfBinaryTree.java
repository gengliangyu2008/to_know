package leetcode;

public class MaximumDepthOfBinaryTree {
    public int maxDepth(TreeNode root) {
    	return getMaxDepth(root);
    }
    
    public int getMaxDepth(TreeNode root) {
    	while( root != null ) {
    		int leftTreeDepth = getMaxDepth( root.left ) + 1;
    		int rightTreeDepth = getMaxDepth( root.right ) + 1;
    		return Math.max(leftTreeDepth, rightTreeDepth);
    	}
    	return 0;
    }
}