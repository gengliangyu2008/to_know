package leetcode;

public class DivideTwoIntegers {
	public int divide(int dividend, int divisor) {
    	if( divisor == 0 ) {
    		throw new IllegalArgumentException("Argument 'divisor' is 0"); 
    	}
    	boolean isPositive = (dividend < 0 && divisor < 0) || (dividend > 0 && divisor > 0);
    	
    	int newDividend = dividend;// Math.abs((long)dividend);
    	int newDivisor = divisor;// Math.abs(divisor);
    	long i = 0;
        if( newDivisor == 1 ) {
            i = newDividend;
        } else {
        	//i = newDividend/newDivisor;
            while( (newDividend -= newDivisor) >= 0 ) {
        	    ++i;
            }
        }
        
        /*if( isPositive && i > Integer.MAX_VALUE ) {
        	i = Integer.MAX_VALUE;
        }*/
        
        return (int)i;
        
        //return isPositive ? (int)i : (int)-i;
    }
	
	public int divideA(int dividend, int divisor) {

	    if(divisor == 0)
	        throw new IllegalArgumentException("Zero as divisor!");

	    int a = Math.abs(dividend);
	    int b = Math.abs(divisor);

	    boolean isPos = true;
	    if(dividend < 0) isPos = !isPos;
	    if(divisor < 0) isPos = !isPos;

	    if(divisor == Integer.MIN_VALUE){

	        if(dividend == Integer.MIN_VALUE) return 1;
	        else return 0;
	    }

	    if(dividend == Integer.MIN_VALUE) {

	        if(divisor == -1){

	            return Integer.MAX_VALUE;
	        } else {
	            // Because Math.abs(Integer.MIN_VALUE) = Integer.MIN_VALUE
	            // we avoid it by adding a positive divisor to Integer.MIN_VALUE
	            // here I combined two cases: divisor > 0 and divisor < 0
	            return divideA((dividend + b), divisor) - divisor/b;
	        }
	    }

	    int res = 0;        
	    int product = b;

	    while(a >= b){

	        int multiplier = 1;
	        while(a - product >= product){

	            product = product << 1;// "product << 1" is actually "product * 2"
	            multiplier = multiplier << 1;
	        }
	        res += multiplier;
	        a -= product;
	        product = b;
	    }

	    return isPos?res:-res;

	}
	
	
	public int divideB(int dividend, int divisor) {

	    int result = 0;        

	    while(dividend >= divisor){
	    	
	        int multiplier = 1;
	        int tempDivisor = divisor;
	        
	        while(dividend - tempDivisor >= tempDivisor){

	        	tempDivisor = tempDivisor << 1;// "product << 1" is actually "product * 2"
	            multiplier = multiplier << 1;
	        }
	        
	        result += multiplier;
	        dividend -= tempDivisor;
	    }
	    
	    return result;
	}
	
	public static void main(String[] args) {
		
		int dividend = 109;
		int divisor = 10;

		long startTime = System.currentTimeMillis();
		int result  = new DivideTwoIntegers().divideB(dividend, divisor);
		long durable = System.currentTimeMillis() - startTime;
		
		System.out.println( "time spend:" + durable + " ,result======" + result );
		
		/*long dividend = 78;
		dividend = dividend << 1;
		
		System.out.println( dividend );*/
	}
}
