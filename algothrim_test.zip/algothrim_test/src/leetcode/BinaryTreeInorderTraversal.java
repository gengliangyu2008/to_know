package leetcode;

import java.util.ArrayList;
import java.util.List;

public class BinaryTreeInorderTraversal {
    public List<Integer> inorderTraversal(TreeNode root) {
        List<Integer> result = new ArrayList<>();
        traverseTreeInOrder(root, result);
        return result;
    }
    
    private void traverseTreeInOrder(TreeNode root, List<Integer> result){
    	if( root == null ) {
    		return;
    	}
    	
		traverseTreeInOrder(root.left, result);
		result.add(root.val);
		traverseTreeInOrder(root.right, result);
    }
}