package leetcode;

import java.util.Objects;

public class AddTwoNumbers {

    public ListNode addTwoNumbers(ListNode node1, ListNode node2) {
        ListNode dummyHead = new ListNode(0);
        ListNode currNode = dummyHead;
        int carry = 0;
        while (node1 != null || node2 != null) {
            int x = (node1 != null) ? node1.val : 0;
            int y = (node2 != null) ? node2.val : 0;
            int sum = carry + x + y;
            carry = sum / 10;
            currNode.next = new ListNode(sum % 10);
            currNode = currNode.next;
            if (node1 != null) node1 = node1.next;
            if (node2 != null) node2 = node2.next;
        }
        if (carry > 0) {
            currNode.next = new ListNode(carry);
        }
        return dummyHead.next;
    }
}
/**
 * Definition for singly-linked list.
 *
 */
class ListNode {
    int val;
    ListNode next;

    ListNode(int x) {
        val = x;
    }
}