package leetcode;

import java.math.BigInteger;

public class PowerCalc {

	public int calcSquare(int i) {
		i = i << i;
		return i;
	}
	
	/*public double myPow(double x, int n) {
        if( n == 0 ) {
            return 1;
        }
        double result = 1;
        
        boolean isNegtiveExponent = false;
        if( n < 0 ) {
        	isNegtiveExponent = true;
            n = -n;
        }
        while( n > 0 ) {
            result=result*x;
            --n;
        }
        return isNegtiveExponent ? (1/result) : result;
    }*/
	
	public double myPow(double x, int n) {
        double result;
        if (n == 0) {
            return 1;
        } else if (n > 0) {
            result = helper(x, n);
        } else {
            result = 1/helper(x, n);
        }
        return result;
    }
	
    private double helper(double x, int n) {
        if (n == 0) {
            return 1;
        } else if (n == 1) {
            return x;
        }
        double ans = helper(x, n/2);
        if (n % 2 == 0) {
            return ans * ans;
        } else {
            return ans * ans * x;
        }
    }
	
	public static void main(String[] args) {
		double d1 = 0.00001;
		int exponent = 2147483647;
		
		/*double d1 = 15;
		int exponent = 3;*/
		
		long start = System.currentTimeMillis();
		double result = new PowerCalc().myPow(d1, exponent);
		long durable = System.currentTimeMillis() - start;
		
		System.out.println( "durable=" + durable + ", result=" + result );
		
		long start2 = System.currentTimeMillis();
		double result2 = Math.pow(d1, exponent);
		long durable2 = System.currentTimeMillis() - start2;
		System.out.println( "durable2=" + durable2 + ", result2=" + result2 );
	}
}
