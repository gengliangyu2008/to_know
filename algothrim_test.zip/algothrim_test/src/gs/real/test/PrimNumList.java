package gs.real.test;

import java.util.ArrayList;
import java.util.List;

public class PrimNumList {

	/**
	 * My own way
	 * */
	public static List<Integer> getAllPrimeNums(int num) {

		List<Integer> list = new ArrayList<>();

		while (num > 1) {
			for (int i = 2; i <= num; i++) {
				if (num % i == 0) {
					list.add(i);
					num = num / i;
					break;
				}
			}
		}

		return list;
	}
	
	/**
	 * This is a new method of doing it.
	 * 
	 */
	public static List<Integer> primeFactors(long number) { 
		List<Integer> primefactors = new ArrayList<>(); 
		long copyOfInput = number;
		
		for (int i = 2; i <= copyOfInput; ) { 
			if (copyOfInput % i == 0) { 
				
				primefactors.add(i);// prime factor 
				 
				copyOfInput /= i; 
				//i--; 
			} else {
				i++;
			}
		}
		return primefactors; 
	}



	public static void main(String[] args) {

		// List<Integer> list = getAllPrimeNums(991);

		List<Integer> list2 = getAllPrimeNums(121);

		System.out.println(list2.toString());
		
		List<Integer> list3 = primeFactors(72);
		
		System.out.println(list3.toString());
	}
}
