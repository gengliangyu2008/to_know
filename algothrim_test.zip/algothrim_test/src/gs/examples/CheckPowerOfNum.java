package gs.examples;

public class CheckPowerOfNum {

	public static boolean isPowerOf10(long l) {
		double d = Math.log10( l );
		
		//return Double.isFinite(d) && Math.round(d) == d;
		return d == (int)d;
	}
	
	public static boolean isPowerOf10ByWhileLoop(long l) {
		
		while( l > 9 && l%10 == 0 ) {
			l = l/10;
			System.out.println("L is:" + l);
		}
		return l == 1;
	}
	
	public static boolean isPowerOf2(long l) {
		return (l & (l-1)) == 0;
	}
	public static void main(String[] args) {
		//System.out.println( isPowerOf10ByWhileLoop(10000) );
		
		
		System.out.println( isPowerOf2(5) );
		
		System.out.println( Integer.toBinaryString(4) );
		System.out.println( Integer.toBinaryString(-4) );
		
		System.out.println( Integer.toBinaryString(5) );
		System.out.println( Integer.toBinaryString(-5) );
		
		System.out.println( 5 & -5 );
	}
}
