package gs.examples;

import java.util.Arrays;

public class AnagramCheck {

	public static boolean iAnagram(String word, String anagram){
        char[] charFromWord = word.toCharArray();
        char[] charFromAnagram = anagram.toCharArray();       
        Arrays.sort(charFromWord);
        Arrays.sort(charFromAnagram);
       
        return Arrays.equals(charFromWord, charFromAnagram);
    }
	
	public static boolean isAnagram1(String str1, String str2) {
		int length = str1.length();
		
		for(int i=0; i<length; i++ ) {
			if ( ! ( str1.charAt(i) == str2.charAt(length -1 - i) ) ) {
				return false;
			}
		}
		
		return true;
	}
	
	public static void main(String[] args) {
		
		String a1 = "1234566666";
		String a2 = "6666654321";
		
		System.out.println( isAnagram1(a1, a2) );
	}
}
