package gs.examples;

public class MedianOfTwoSortedArray {

	public static double findMedianSortedArrays(int[] nums1, int[] nums2) {
        int length1 = nums1.length;
        int length2 = nums2.length;

        if (length1 > length2) {
        	return findMedianSortedArrays(nums2, nums1);
        }
        
        int wholeMid = (length1 + length2 + 1) / 2;
        
        int l = 0; int r = length1;
        
        System.out.println("l============" + l + ",r==============" + r);
        while (l < r) {
        	int m1 = l + (r - l) / 2;
        	int m2 = wholeMid - m1;

        	System.out.println("first index is " + m1 + " ,second index is " + m2);
        	if (nums1[m1] < nums2[m2 - 1]) {
        		System.out.println( nums1[m1] + "<" + nums2[m2 - 1]);
        		
        		l = m1 + 1;
        	} else {
        		System.out.println( nums1[m1] + ">=" + nums2[m2 - 1]);
        		r = m1;
        	}
        	System.out.println("l============" + l + ",r==============" + r);
        	
        }
        int m1 = l;
        int m2 = wholeMid - m1;

        int c1 = Math.max( nums1[m1 - 1], nums2[m2 - 1]);

        if ((length1 + length2) % 2 == 1) {
        	System.out.println("results===========" + nums1[m1 - 1] + "," + nums2[m2 - 1]);
        	return c1;
        }

        int c2 = Math.min( nums1[m1], nums2[m2]);

        System.out.println("results===========c1==" + c1 + ",c2==" + c2);
        return (c1 + c2) / 2.0;
    }
	
	public static void main(String[] args) {
		//int[] arr1 = {2,3,4,11, 100};
		//int[] arr2 = {5,7,8,9, 10, 20, 30, 40, 50};
		
		//int[] arr1 = {1, 2, 3, 4, 10};
		//int[] arr2 = {5, 6, 7, 8, 9, 11, 20};
		
		int[] arr1 = {1, 3, 5, 7};
		int[] arr2 = {2, 4, 6, 8, 10};
		System.out.println( findMedianSortedArrays(arr1, arr2) );
	}
}

