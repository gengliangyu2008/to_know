package gs.examples;

public class IntegerReverse {

	public static int reverse(int num) {
		int result = 0;
		
		while( true ) {
			
			if( Math.abs(num) > 9 ) {
				int remainder = num%10;
				num = num/10;
				
				result = result*10 + remainder;
				
			} else {
				result = result*10 + num;
				break;
			}
		}
		return result;
	}
	
	public static int reverse1(int num) {
		int result = 0;
		
		while( num != 0 ) {
			int remainder = num%10;
			result = result*10 + remainder;

			num = num/10;
		}
		return result;
	}
		
	public static void main(String[] args) {
		
		System.out.println( reverse1( -987654 ) );
	}
}
