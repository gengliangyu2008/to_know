package gs.examples;

public class BinarySearch {

	public static int search(int[] arr, int num) {
		int l = 0;
		int r = arr.length - 1;
		
		int index = -1;
		while( l <= r ) {
			//index = (l+r+1)/2;
			
			index = l + (r - l) / 2;
			
			if( num > arr[index] ) {
				//l = index;
				l = index + 1;
				continue;
			}
			if( num < arr[index] ) {
				//r = index;
				r = index - 1;
				continue;
			}
			return index;
		}
		return -1;
	}
	
	public static void main(String[] args) {
		int[] arr = {1, 3, 4, 6, 7, 8, 9, 20, 99, 100, 166, 190};
		
		//System.out.println( search(arr, 190) );
		System.out.println( search(arr, 20) );
	}
}
