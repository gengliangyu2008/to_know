package gs.examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Permutation {
	
	static int getFactorial(int n) {
		if( n == 1 ) {
			return 1;
		}
		return n*getFactorial(n-1);
	}
	
	static String swapString(String str, int i, int j) {
		char[] arr = str.toCharArray();
		char temp = arr[i];
		arr[i] = arr[j];
		arr[j] = temp;
		
		return new String(arr);
	}

	// An iterative function to print all permutations of s.
	static void printPermutation(String s) {

		int length = s.length();
	    int factorial = getFactorial(length);
	 
	    // Point j to the 2nd position
	    int j = 1;
	 
	    // To store position of character to be fixed next. m is used as in index in s[].
	    int fixedPos = 0;
	 
	    // Iterate while permutation count is smaller than n! which fc
	    for (int index = 0; index < factorial; ) {
	        // Store perm as current permutation
	    	String temp = new String(s);
	 
	        // Fix the first position and iterate (n-1)
	        // characters upto (n-1)!
	        // k is number of iterations for current first character.
	        int k = 0;
	        while (k != factorial/length) {
	        	
	            // Swap jth value till it reaches the end position
	            while (j != length-1) {
	 
	            	// Print current permutation
	                System.out.println( temp );
	                
	                // Swap perm[j] with next character
	                temp = swapString(temp, j, j+1);
	 
	                // Increment count of permutations for this cycle.
	                k++;
	 
	                // Increment permutation count
	                index++;
	 
	                // Increment 'j' to swap with next character
	                j++;
	            }
	 
	            // Again point j to the 2nd position
	            j = 1;
	        }
	 
	        // Move to next character to be fixed in s[]
	        fixedPos++;
	 
	        // If all characters have been placed at
	        if (fixedPos == length)
	           break;
	 
	        // Move next character to first position
	        s = swapString(s, 0, fixedPos);
	    }
	}
	
	
	static void printPermutationNew(String s) {

		int length = s.length();
	    int factorial = getFactorial(length);
	 
	    // Point j to the 2nd position
	    int j = 1;
	    
	    int posToBeFixed = 0;
	 
	    // Iterate while permutation count is smaller than n! which fc
	    while( true ) {
	    	
	        // Store perm as current permutation
	    	String temp = new String(s);
	    	System.out.println("current===============" + temp);
	 
	        // Fix the first position and iterate (n-1)
	        // characters upto (n-1)!
	        // k is number of iterations for current first character.
	        int k = 0;
	        while (k < factorial/length) {
	        	
	            // Swap jth value till it reaches the end position
	            while (j < length-1) {
	 
	            	// Print current permutation
	            	System.out.println( temp );
	                
	                // Swap perm[j] with next character
	                temp = swapString(temp, j, j+1);
	                
	                // Increment count of permutations for this cycle.
	                k++;
	 
	                // Increment 'j' to swap with next character
	                j++;
	            }
	 
	            // Again point j to the 2nd position
	            j = 1;
	        }
	 
	        // Move to next character to be fixed in s[]
	        posToBeFixed++;
	        if( posToBeFixed >= length ) {
	        	break;
	        }
	 
	        // Move next character to first position
	        s = swapString(s, 0, posToBeFixed);
	    }
	}
	
	static void printPermutationNew1(String s) {

		int length = s.length();
	    int factorial = getFactorial(length);
	 
	    // Point j to the 2nd position
	    int switchPos = 1;
	    
	    int posToBeFixed = 0;
	 
	    // Iterate while permutation count is smaller than n! which fc
	    while( true ) {
	    	
	        // Store perm as current permutation
	    	String temp = new String(s);
	    	System.out.println("current===============" + temp);
	 
	        // Fix the first position and iterate (n-1)
	        // characters upto (n-1)!
	        // k is number of iterations for current first character.
	        int count = 0;
	        while (count < factorial/length) {
	        	
	            // Swap jth value till it reaches the end position
	            while (switchPos < length-1) {
	 
	            	// Print current permutation
	            	System.out.println( temp );
	                
	                // Swap perm[j] with next character
	                temp = swapString(temp, switchPos, switchPos+1);
	                
	                // Increment count of permutations for this cycle.
	                count++;
	 
	                // Increment 'j' to swap with next character
	                switchPos++;
	            }
	 
	            // Again point j to the 2nd position
	            switchPos = 1;
	        }
	 
	        // Move to next character to be fixed in s[]
	        posToBeFixed++;
	        if( posToBeFixed >= length ) {
	        	break;
	        }
	 
	        // Move next character to first position
	        s = swapString(s, 0, posToBeFixed);
	    }
	}
	
	public static void main(String[] args) {
		String s = "abcd";
		
		printPermutation(s);
		//printPermutationNew(s);
		
		//Collections.swap
	}
}
