package gs.examples;

public class BinarySearchTreeExamples {

	public int bstDistance(int[] values, int n, int node1, int node2) {
		//1. create tree
		BSTNode root = new BSTNode(null, values[0]);
		for( int i=1; i<values.length; i++ ) {
			root.addNode( values[i] );
		}
		
		//2. check if nodes exist
		BSTNode bstNode1 = searchNode(root, node1);
		BSTNode bstNode2 = searchNode(root, node2);
		
		if( bstNode1 == null || bstNode2 == null ) {
			return -1;
		}
		
		//3. get LCA
		BSTNode lcaNode = findLCA(root, bstNode1, bstNode2);
		
		//4. getDepth
		int lcaDepth = getDepth(root, lcaNode);
		int node1Depth = getDepth( root ,  bstNode1);
		int node2Depth = getDepth( root ,  bstNode2);
		
		return node1Depth + node2Depth - 2*lcaDepth;
	}
	
	public BSTNode searchNode(BSTNode root, int value) {
		if( root == null ) {
			return null;
		}
		
		if( root.value == value) {
			return root;
		}
		
		if( value < root.value ) {
			return searchNode(root.left, value);
		}
		
		return searchNode(root.right, value);
	}
	
	public BSTNode findLCA(BSTNode root, BSTNode node1, BSTNode node2 ) {
		
		if( root == null ) {
			return null;
		}
		
		if( root.value == node1.value || root.value == node2.value ) {
			return root;
		}
		
		BSTNode left = findLCA(root.left, node1, node2);
		BSTNode right = findLCA(root.right, node1, node2);
		
		if( left != null && right != null )
			return root;
		
		return left == null ? right : left;
	}
	
	public int getDepth(BSTNode root, BSTNode target) {
		if( root == null ) {
			return -1;
		}
		
		if( target.value == root.value ) {
			return 0;
		}
		
		int leftDepth = -1;
		int rightDepth = -1;
		
		if( target.value < root.value) {
			leftDepth = getDepth(root.left, target);
		} else {
			rightDepth = getDepth(root.right, target);
		}
		
		if( leftDepth == -1 && rightDepth == -1 ) {
			return -1;
		}
		return leftDepth  == -1 ? rightDepth + 1 : leftDepth + 1;
	}
	
	/*public BSTNode searchNodeIteratively(BSTNode root, int value) {
		
		BSTNode result = null;
		
		BSTNode tempNode = root;
		while( tempNode != null  ) {
			
			if( tempNode.value == value ) {
				result = tempNode;
				break;
			}
			
			if( value < tempNode.value) {
				tempNode = tempNode.left;
			} else {
				tempNode = tempNode.right;
			}
		}
		return result;
	}*/
	
	public static void main(String[] args) {
		BinarySearchTreeExamples bst = new BinarySearchTreeExamples();
		
		/**
		 * The tree is from below link:
		 *  
		 * http://lcm.csa.iisc.ernet.in/dsa/node91.html
		 * 
		 */
		
		int[] arr = {13, 3, 4, 12, 14, 10, 5, 1, 8, 2, 7, 9, 11, 6, 18};
		
		System.out.println("distance================" + bst.bstDistance(arr, arr.length, 10, 19) );
	}
}

class BSTNode {
	
	public BSTNode left;
	public BSTNode right;
	public BSTNode parent;
	
	public int value;

	BSTNode(BSTNode parent, int value) {
		this.value = value;
		this.parent = parent;
		this.left = null;
		this.right = null;
	}
	
	public void addNode(int newValue) {
		if( newValue < this.value ) {
			
			if( this.left != null ) {
				this.left.addNode(newValue);
			} else {
				this.left = new BSTNode(this, newValue);
			}
			
		} else {
			if( right != null ) {
				right.addNode(newValue);
			} else {
				right = new BSTNode(this, newValue);
			}
		}
	}
}