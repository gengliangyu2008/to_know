package gs.examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.function.ToIntFunction;
import java.util.stream.Collectors;
import java.util.stream.Stream;

//import org.apache.commons.lang3.ArrayUtils;

public class ArrayToCollectionMutualConvertion {

	public static void convertListToArray() {
		List<Integer> list = new ArrayList<>();
		
		list.add(1);
		list.add(2);
		list.add(null);
		list.add(4);
		
		
		//Integer[] arrFromList = (Integer[])list.toArray();
		
		ToIntFunction<Integer> func = new ToIntFunction<Integer>() {
			
			@Override
			public int applyAsInt(Integer value) {
				
				return value == null ? 0 : value.intValue();
			}
		};
		
		int[] arr = list.stream().mapToInt( func ).toArray();
		
		System.out.println( "final arr=============" + Arrays.toString( arr ) );
		
		//ArrayUtils.toPrimitive(passInArr, 0);
	}
	
	public void convertArrayToList() {
		int[] arr1 = null;
		
		Arrays.asList(arr1);
		
		Arrays.stream(arr1).boxed().collect(Collectors.toList());
		
		Arrays.stream(arr1);
	}
	
	public void convertSetToArray() {
		Set<Integer> s = new LinkedHashSet<Integer>();
		
		ToIntFunction<Integer> func = (Integer i) -> i.intValue();
		
		Stream<Integer> stream =  s.stream();
		
		int[] arr = s.stream().mapToInt( func ).toArray();
		
		//int[] arr1 = s.stream().un
		
		Integer[] arrFromSet = (Integer[])s.toArray();
	}
	
	public static void main(String[] args) {

	}
}
