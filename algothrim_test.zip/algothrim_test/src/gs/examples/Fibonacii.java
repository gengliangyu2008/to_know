package gs.examples;

public class Fibonacii {

	public static int calc(int num) {
		int prev = 1;
		int curr = 1;

		int result = 0;
		for( int i = 1; i < num; i++ )  {
			result = curr + prev;
			prev = curr;
			curr = result;

			System.out.println(result);
		}
		
		return result;
	}
	
	public static int calcRecursively(int i) {
		if( i == 1 || i == 2 ) {
			return 1;
		}
		return calcRecursively(i -1) + calcRecursively(i - 2);
	}
	
	
	/**
	 * 
	 * 
	 * 
	 * 
	 * i = 1; return 1
	 * i = 2; return 1
	 * i = 3; return calc 2 + calc 1
	 * i = 4; return calc 3 + calc 2
	 */
	
	public static void main(String[] args) {
		System.out.println("==================================" + calc(10));
		
		System.out.println("==================================" + calcRecursively(10));
	}
}
