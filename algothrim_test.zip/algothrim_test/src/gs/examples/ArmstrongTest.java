package gs.examples;

public class ArmstrongTest {

	public static boolean isAmstrong(int num) {
		int result = 0;
		int newNum = num;
		
		while( newNum != 0 ) {
			int remainder = newNum%10;
			result += remainder*remainder*remainder;
			//result = Math.pow(remainder, 3);
			
			newNum = newNum/10;
		}
		
		return result == num;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println( isAmstrong(153) );
		System.out.println( isAmstrong(150));
	}

}
