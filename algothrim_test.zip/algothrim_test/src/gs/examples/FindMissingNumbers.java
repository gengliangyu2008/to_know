package gs.examples;

import java.util.Arrays;
import java.util.BitSet;

public class FindMissingNumbers {

	private static void printMissingNumber(int[] numbers, int count) {
        int missingCount = count - numbers.length;
        BitSet bitSet = new BitSet(count);
 
        for (int number : numbers) {
            bitSet.set(number - 1);
        }
 
        System.out.printf("Missing numbers in integer array %s, with total number %d is %n",
        Arrays.toString(numbers), count);
        int lastMissingIndex = 0;

        for (int i = 0; i < missingCount; i++) {
            lastMissingIndex = bitSet.nextClearBit(lastMissingIndex);
            System.out.println(++lastMissingIndex);
        }
    }
	
	private static void findMissNums(int[] numbers, int count) {
		
		int missCount = count - numbers.length;
		BitSet bitSet = new BitSet(count);
		
		for(int i = 0; i<numbers.length; i++ ) {
			bitSet.set(numbers[i]);
		}
		
		int lastMissIndex = 1;
		for( int i=0; i<missCount; i++ ) {
			lastMissIndex = bitSet.nextClearBit(lastMissIndex);
			System.out.println( lastMissIndex++ );
		}
	}
	
	
	private static void findMissNumsInDuplicates(int[] nums, int count) {
		int prevNum = 0;
		for(int i=0; i<nums.length; i++ ) {
			while( nums[i] - prevNum > 1 ) {
				prevNum++;
				System.out.println( prevNum );
			}
			prevNum = nums[i];
		}
	}
	
	public static void main(String[] args) {
		int[] nums = {1,2,3,4,6,6,6,6,6,8,9,10,};
		//findMissNums(nums, 10);
		
		//findMissNumsInDuplicates(nums, 0);
		
		System.out.println( 9 >> 2 );
	}
}
